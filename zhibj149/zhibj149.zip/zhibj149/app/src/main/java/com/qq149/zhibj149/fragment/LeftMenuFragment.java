package com.qq149.zhibj149.fragment;


import android.app.Activity;
import android.view.View;
import com.qq149.zhibj149.R;

/**
 * @author zhuww
 * @description: 149
 * @date :2019/5/18 11:21
 */
public class  LeftMenuFragment extends BaseFragment{



    @Override
    public View initView() {
        View view = View.inflate(mActivity,R.layout.fragment_left_menu,null);
        return view;
    }

    @Override
    public void initData() {

    }


}
