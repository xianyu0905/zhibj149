package com.qq149.zhibj149.fragment;

import android.app.Activity;
import android.content.Context;
import android.view.View;

import com.qq149.zhibj149.R;
import com.qq149.zhibj149.base.BasePager;

/**
 * @author zhuww
 * @description: 149
 * @date :2019/5/18 11:18
 * 主页面Fragment
 */
public class ContentFragment extends BaseFragment {




    @Override
    public View initView() {
        View view = View.inflate(mActivity, R.layout.fragment_content,null);
        return view;
    }

    @Override
    public void initData() {

    }
    //你等等，我打开我的对一下
    //好像找到了
    //你好像少个页面
}
